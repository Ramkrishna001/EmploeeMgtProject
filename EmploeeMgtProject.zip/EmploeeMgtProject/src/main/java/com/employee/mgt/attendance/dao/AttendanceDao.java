package com.employee.mgt.attendance.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee.mgt.model.Attendance;

@Repository
public interface AttendanceDao extends JpaRepository<Attendance, Long> {

}
