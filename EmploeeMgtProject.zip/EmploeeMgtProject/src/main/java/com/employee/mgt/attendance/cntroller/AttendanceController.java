package com.employee.mgt.attendance.cntroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.mgt.attendance.service.AttendanceService;
import com.employee.mgt.emp.service.EmployeeService;
import com.employee.mgt.model.Attendance;
import com.employee.mgt.model.Employee;

@RestController
@RequestMapping("attendance")
public class AttendanceController {
	
	@Autowired
	AttendanceService attendanceService;
	
	@Autowired
	EmployeeService employeeService;

	@PostMapping("getAttendance")
	public Attendance getAttendance(@RequestBody Attendance attendance) {
		
		Employee employee = employeeService.findEmployee(attendance.getEmp().getId());
		attendance.setEmp(employee);
		return attendanceService.getAttendance(attendance);
	}

}
