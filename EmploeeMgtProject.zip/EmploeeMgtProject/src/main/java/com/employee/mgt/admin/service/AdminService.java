package com.employee.mgt.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.mgt.admin.dao.AdminDao;

@Service
public class AdminService {

	@Autowired
	AdminDao adminDao;
	
}
