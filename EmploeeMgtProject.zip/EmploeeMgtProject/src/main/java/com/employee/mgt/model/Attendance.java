package com.employee.mgt.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "attendane")
public class Attendance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne
	@JoinColumn
	private Employee emp;
	
	private String attendanceTakerRole;
	private Long attendanceTakerId;
	
	@JsonFormat(pattern = "dd-mm-yyyy")
	private Date attendanceDate;
	
	private Long punchIn;
	private Long punchOut;
	private String status;

	public Attendance() {
	}

	public Attendance(Employee emp, String attendanceTakerRole, Long attendanceTakerId, Date attendanceDate,
			Long punchIn, Long punchOut, String status) {

		this.emp = emp;
		this.attendanceTakerRole = attendanceTakerRole;
		this.attendanceTakerId = attendanceTakerId;
		this.attendanceDate = attendanceDate;
		this.punchIn = punchIn;
		this.punchOut = punchOut;
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee empId) {
		this.emp = empId;
	}

	public String getAttendanceTakerRole() {
		return attendanceTakerRole;
	}

	public void setAttendanceTakerRole(String attendanceTakerRole) {
		this.attendanceTakerRole = attendanceTakerRole;
	}

	public Long getAttendanceTakerId() {
		return attendanceTakerId;
	}

	public void setAttendanceTakerId(Long attendanceTakerId) {
		this.attendanceTakerId = attendanceTakerId;
	}

	public Date getAttendanceDate() {
		return attendanceDate;
	}

	public void setAttendanceDate(Date attendanceDate) {
		this.attendanceDate = attendanceDate;
	}

	public Long getPunchIn() {
		return punchIn;
	}

	public void setPunchIn(Long punchIn) {
		this.punchIn = punchIn;
	}

	public Long getPunchOut() {
		return punchOut;
	}

	public void setPunchOut(Long punchOut) {
		this.punchOut = punchOut;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
