package com.employee.mgt.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "authority")
public class Autority {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String autorityName;
	private String authorityName;
	private String allAutorities;
	private String readOnly;
	private String writeOnly;
	private String removeOnly;

	public Autority() {
	}

	@OneToOne
	private Admin admin;

	@OneToOne
	private Employee employee;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAutorityName() {
		return autorityName;
	}

	public void setAutorityName(String autorityName) {
		this.autorityName = autorityName;
	}

	public String getAuthorityName() {
		return authorityName;
	}

	public void setAuthorityName(String authorityName) {
		this.authorityName = authorityName;
	}

	public String getAllAutorities() {
		return allAutorities;
	}

	public void setAllAutorities(String allAutorities) {
		this.allAutorities = allAutorities;
	}

	public String getReadOnly() {
		return readOnly;
	}

	public void setReadOnly(String readOnly) {
		this.readOnly = readOnly;
	}

	public String getWriteOnly() {
		return writeOnly;
	}

	public void setWriteOnly(String writeOnly) {
		this.writeOnly = writeOnly;
	}

	public String getRemoveOnly() {
		return removeOnly;
	}

	public void setRemoveOnly(String removeOnly) {
		this.removeOnly = removeOnly;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
