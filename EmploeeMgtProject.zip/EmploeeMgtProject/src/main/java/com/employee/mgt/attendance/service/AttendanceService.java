package com.employee.mgt.attendance.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.mgt.attendance.dao.AttendanceDao;
import com.employee.mgt.model.Attendance;

@Service
public class AttendanceService {

	@Autowired
	AttendanceDao attendanceDao;
	
	public Attendance getAttendance(Attendance attendance)
	{
		return attendanceDao.save(attendance);
	}
	
}
