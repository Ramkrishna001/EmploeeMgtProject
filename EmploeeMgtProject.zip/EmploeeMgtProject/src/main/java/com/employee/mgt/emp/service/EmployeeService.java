package com.employee.mgt.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.employee.mgt.emp.dao.EmployeeDao;
import com.employee.mgt.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	
	public List<Employee> getAllEmployees() {
		List<Employee> empList = employeeDao.findAll();
		if (empList.size() > 0) {
			return empList;
		}

		return new ArrayList<Employee>();
	}
	
	public Employee registerEmployee(Employee employee)
	{
		return employeeDao.save(employee);
	}
	
	public Employee updateEmployee(Long id, Employee employee)
	{
		Optional<Employee> empId = employeeDao.findById(id);
		
		if(empId != null)
		{
			return employeeDao.save(employee);
		}
		
		return new Employee();
	}

	public Employee deleteEmployee(Long id) {
		
     Optional<Employee> emp = employeeDao.findById(id);
		
		if(emp != null)
		{
		   employeeDao.delete(emp.get());
		}
		return emp.get();
	}
	
	public Employee findEmployee(Long id)
	{
		 Optional<Employee> emp = employeeDao.findById(id);
		 
		 return emp.get();
	}

}
